<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-28 02:10:58 --> 404 Page Not Found: GymContent/index
ERROR - 2018-08-28 02:11:27 --> 404 Page Not Found: GymContent/index
ERROR - 2018-08-28 02:13:21 --> 404 Page Not Found: GymContent/index
ERROR - 2018-08-28 02:13:23 --> 404 Page Not Found: GymContent/index
ERROR - 2018-08-28 02:13:49 --> 404 Page Not Found: GymContent/index
ERROR - 2018-08-28 03:49:04 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-28 03:49:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-08-28 05:35:43 --> 404 Page Not Found: Bower_components/moment
ERROR - 2018-08-28 05:35:43 --> 404 Page Not Found: Bower_components/bootstrap-daterangepicker
ERROR - 2018-08-28 05:35:43 --> 404 Page Not Found: Bower_components/moment
ERROR - 2018-08-28 05:35:43 --> 404 Page Not Found: Bower_components/bootstrap-daterangepicker
ERROR - 2018-08-28 07:37:42 --> Severity: Notice --> Undefined property: MasterDataAdminImageGallery::$bulletinboard C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 55
ERROR - 2018-08-28 07:37:42 --> Severity: error --> Exception: Call to a member function loadBranch() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 55
ERROR - 2018-08-28 07:39:09 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 102
ERROR - 2018-08-28 08:02:35 --> Severity: Notice --> Undefined index: arr C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 88
ERROR - 2018-08-28 08:02:54 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 88
ERROR - 2018-08-28 08:03:40 --> Severity: Notice --> Undefined index: data C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 88
ERROR - 2018-08-28 08:08:11 --> Severity: Notice --> Undefined index: thisarray C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 88
ERROR - 2018-08-28 08:27:05 --> Severity: error --> Exception: Call to undefined function {"showtobranch":"1","imagetitle":"asd","imageorder":"","description":"","imagestatus":"yes","deletestatus":"no","photo":{}}() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 95
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1566
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> sort() expects parameter 1 to be array, null given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1567
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1579
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1584
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> array_diff(): Argument #1 is not an array C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1572
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> ksort() expects parameter 1 to be array, string given C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1579
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1584
ERROR - 2018-08-28 08:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 1595
ERROR - 2018-08-28 08:29:44 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 89
ERROR - 2018-08-28 08:30:46 --> Severity: error --> Exception: Call to undefined function {"showtobranch":"1","imagetitle":"asd","imageorder":"","description":"","imagestatus":"yes","deletestatus":"no","photo":{}}() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 95
ERROR - 2018-08-28 08:31:19 --> Severity: error --> Exception: Call to undefined function {"showtobranch":"1","imagetitle":"asd","imageorder":"","description":"","imagestatus":"yes","deletestatus":"no","photo":{}}() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 95
ERROR - 2018-08-28 08:35:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 91
ERROR - 2018-08-28 08:35:31 --> Severity: Notice --> Undefined variable: data_input C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 103
ERROR - 2018-08-28 08:37:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 91
ERROR - 2018-08-28 08:37:02 --> Severity: Notice --> Undefined variable: data_input C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 103
ERROR - 2018-08-28 08:38:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 91
ERROR - 2018-08-28 08:38:04 --> Severity: Notice --> Undefined variable: data_input C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 103
ERROR - 2018-08-28 08:42:05 --> Query error: Unknown column 'ImageDescription' in 'field list' - Invalid query: INSERT INTO `masterdatarolemapping` (`AddedBy`, `AddedDate`, `DeleteStatus`, `ImageDescription`, `ImageLink`, `ImageOrderIndex`, `ImageStatus`, `ImageTitle`, `ShowToBranch`) VALUES ('1','2018-08-28','no','','8c514c05596666363e2069b116929614.png','','yes','qwe','1'), ('1','2018-08-28','no','','8c514c05596666363e2069b116929614.png','','yes','qwe','2')
ERROR - 2018-08-28 08:42:46 --> Query error: Unknown column 'ImageDescription' in 'field list' - Invalid query: INSERT INTO `masterdatarolemapping` (`AddedBy`, `AddedDate`, `DeleteStatus`, `ImageDescription`, `ImageLink`, `ImageOrderIndex`, `ImageStatus`, `ImageTitle`, `ShowToBranch`) VALUES ('1','2018-08-28','no','','d16489147809d7f7a28e972410e25740.png','','yes','qwe','1'), ('1','2018-08-28','no','','d16489147809d7f7a28e972410e25740.png','','yes','qwe','2')
