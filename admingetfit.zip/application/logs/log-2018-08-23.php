<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-23 01:46:12 --> Severity: Notice --> Undefined property: FranchiseUserInformation::$mainuserinformation C:\xampp\htdocs\admingetfit\application\controllers\registeruser\FranchiseUserInformation.php 63
ERROR - 2018-08-23 01:46:12 --> Severity: error --> Exception: Call to a member function loadUser() on null C:\xampp\htdocs\admingetfit\application\controllers\registeruser\FranchiseUserInformation.php 63
ERROR - 2018-08-23 01:48:16 --> Query error: Unknown column 'A.EntryShowToBranch' in 'where clause' - Invalid query: SELECT `A`.*, `RoleName`, `PositionName`
FROM `gymfranchiselogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`.`MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`positionID`
WHERE `A`.`EntryShowToBranch` = '2'
AND `A`.`ShowToBranchRole` = '2'
ERROR - 2018-08-23 03:04:37 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:16:18 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:45:11 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:45:19 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:45:28 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:46:16 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:46:52 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:47:28 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:47:42 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:48:03 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:48:14 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:52:39 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:56:36 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 03:56:38 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT *, "NULL" AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 04:00:07 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`MasterDataBulletinBoardDetailsID` = '1'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 04:00:10 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`MasterDataBulletinBoardDetailsID` = '1'
AND `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 07:51:37 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT `A`.`BranchType`
FROM `branchdetails` as `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`BranchDetailsID` = `A`.`SysID`
WHERE `B`.`SysID` = '1'
AND `BranchStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 07:51:54 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT `A`.`BranchType`
FROM `branchdetails` as `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`BranchDetailsID` = `A`.`SysID`
WHERE `B`.`SysID` = '1'
AND `BranchStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 07:52:46 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT `A`.`BranchType`
FROM `branchdetails` as `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`BranchDetailsID` = `A`.`SysID`
WHERE `B`.`SysID` = '1'
AND `BranchStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-23 07:53:24 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:54:10 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:55:25 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:55:26 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:56:15 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:56:35 --> Severity: Notice --> Undefined index: BranchType C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 93
ERROR - 2018-08-23 07:57:03 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 94
ERROR - 2018-08-23 07:59:40 --> Severity: Notice --> Trying to get property 'BranchType' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 94
