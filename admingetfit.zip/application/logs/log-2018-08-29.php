<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-29 00:59:05 --> Query error: Unknown column 'B.EntryShowToBranchRole' in 'where clause' - Invalid query: SELECT *
FROM `masterdatabulletinboarddetails` as `A`
INNER JOIN `masterdatabulletinboard` as `B` ON `B`.`SysID` = `A`.`MasterDataBulletinBoardDetailsID`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`EntryShowToBranch` = '1'
AND `B`.`EntryShowToBranchRole` = '1'
ERROR - 2018-08-29 00:59:36 --> Query error: Unknown column 'A.MasterDataBulletinBoardDetailsID' in 'on clause' - Invalid query: SELECT *
FROM `masterdatabulletinboarddetails` as `A`
INNER JOIN `masterdatabulletinboard` as `B` ON `B`.`SysID` = `A`.`MasterDataBulletinBoardDetailsID`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`EntryShowToBranch` = '1'
AND `B`.`ShowToBranchRole` = '1'
ERROR - 2018-08-29 01:17:29 --> Query error: Unknown column 'A.SysID =' in 'field list' - Invalid query: SELECT *, `A`.`SysID =` `DetailsID`, `B`.`SysID =` `sysID`
FROM `masterdatabulletinboarddetails` as `A`
INNER JOIN `masterdatabulletinboard` as `B` ON `A`.`SysID` = `B`.`MasterDataBulletinBoardDetailsID`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`EntryShowToBranch` = '1'
AND `B`.`ShowToBranchRole` = '1'
ERROR - 2018-08-29 01:18:16 --> Query error: Unknown column 'A.SysID =' in 'field list' - Invalid query: SELECT *, `A`.`SysID =` `DetailsID`, `B`.`SysID =` `sysID`
FROM `masterdatabulletinboarddetails` as `A`
INNER JOIN `masterdatabulletinboard` as `B` ON `A`.`DetailsID` = `B`.`MasterDataBulletinBoardDetailsID`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`EntryShowToBranch` = '1'
AND `B`.`ShowToBranchRole` = '1'
ERROR - 2018-08-29 01:20:38 --> Query error: Unknown column 'A.DetailsID' in 'on clause' - Invalid query: SELECT *, `A`.`SysID` AS `DetailsID`, `B`.`SysID` AS `sysID`
FROM `masterdatabulletinboarddetails` as `A`
INNER JOIN `masterdatabulletinboard` as `B` ON `A`.`DetailsID` = `B`.`MasterDataBulletinBoardDetailsID`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`EntryShowToBranch` = '1'
AND `B`.`ShowToBranchRole` = '1'
ERROR - 2018-08-29 01:34:13 --> Query error: Unknown column 'A.EntryStatus' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdataadminimagegallery` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
WHERE `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-08-29 01:34:45 --> Query error: Unknown column 'A.EntryShowToBranch' in 'on clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdataadminimagegallery` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
WHERE `A`.`ImageStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-08-29 01:59:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-29 01:59:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-29 01:59:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `masterdataadminimagegallery` (0, 1) VALUES (Array, Array)
ERROR - 2018-08-29 02:08:34 --> Query error: Unknown column 'A.ImageStatus' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdataadminimagegalleryshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`ShowToBranch`
WHERE `A`.`masterdataadminimagegalleryID` = '0'
AND `A`.`ImageStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-08-29 02:56:54 --> Severity: Notice --> Undefined property: MasterDataTrainingVideo::$bulletinboard C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataTrainingVideo.php 54
ERROR - 2018-08-29 02:56:54 --> Severity: error --> Exception: Call to a member function loadBranch() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataTrainingVideo.php 54
ERROR - 2018-08-29 03:20:33 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataTrainingVideo_.php 133
ERROR - 2018-08-29 03:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataTrainingVideo_.php 133
ERROR - 2018-08-29 03:20:33 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataTrainingVideo_.php 137
ERROR - 2018-08-29 03:21:01 --> Query error: Unknown column 'A.ImageStatus' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatatrainingvideoshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`ShowToBranch`
WHERE `A`.`masterdatatrainingvideoID` = '2'
AND `A`.`ImageStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-08-29 04:44:42 --> Severity: error --> Exception: Call to undefined method GymContent_::selectBranches() C:\xampp\htdocs\admingetfit\application\models\gym\GymContent_.php 6
ERROR - 2018-08-29 04:45:01 --> Severity: error --> Exception: Call to undefined method GymContent_::selectBranches() C:\xampp\htdocs\admingetfit\application\models\gym\GymContent_.php 6
ERROR - 2018-08-29 05:04:51 --> 404 Page Not Found: gym/GymContent/index
ERROR - 2018-08-29 05:04:51 --> 404 Page Not Found: gym/GymContent/index
ERROR - 2018-08-29 05:04:52 --> 404 Page Not Found: gym/GymContent/index
ERROR - 2018-08-29 05:05:50 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-29 05:05:52 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-29 05:05:52 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-29 05:05:53 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-29 05:05:53 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-29 05:06:10 --> 404 Page Not Found: gym/GymContent/loadBranch
ERROR - 2018-08-29 05:07:04 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 51
ERROR - 2018-08-29 05:07:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 52
ERROR - 2018-08-29 05:07:04 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 61
ERROR - 2018-08-29 05:07:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentPromo_.php 47
ERROR - 2018-08-29 05:09:49 --> Query error: Unknown column 'PromoStatus' in 'field list' - Invalid query: INSERT INTO `gymcontentpromoshowto` (`AddedBy`, `AddedDate`, `DeleteStatus`, `PromoStatus`, `ShowToBranch`, `gymcontentpromoID`) VALUES ('1','2018-08-29','no','yes','1',2), ('1','2018-08-29','no','yes','2',2)
ERROR - 2018-08-29 05:16:11 --> Query error: Unknown column 'A.ImageStatus' in 'where clause' - Invalid query: SELECT `A`.*
FROM `gymcontentpromo` as `A`
WHERE `A`.`DeleteStatus` = 'no'
AND `A`.`ImageStatus` = 'yes'
ERROR - 2018-08-29 05:16:26 --> Query error: Unknown column 'A.ImageStatus' in 'where clause' - Invalid query: SELECT `A`.*
FROM `gymcontentpromo` as `A`
WHERE `A`.`DeleteStatus` = 'no'
AND `A`.`ImageStatus` = 'yes'
ERROR - 2018-08-29 05:16:36 --> Severity: Notice --> Undefined property: stdClass::$ShowToBranch C:\xampp\htdocs\admingetfit\application\models\gym\GymContentPromo_.php 56
ERROR - 2018-08-29 06:02:35 --> Severity: error --> Exception: Call to undefined method GymContentPromo_::updateGymContentPromo() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 112
ERROR - 2018-08-29 06:55:42 --> 404 Page Not Found: Assets/TrainingImage
ERROR - 2018-08-29 06:56:16 --> 404 Page Not Found: Assets/TrainingImage
ERROR - 2018-08-29 06:56:41 --> 404 Page Not Found: Assets/TrainingImage
ERROR - 2018-08-29 07:09:38 --> 404 Page Not Found: 05977ce41e1f4e8340d68412c0f725adjpg/index
ERROR - 2018-08-29 07:09:38 --> 404 Page Not Found: 5a574e50649b1e7e6bafec08870cc40ejpg/index
ERROR - 2018-08-29 07:09:38 --> 404 Page Not Found: Dd4cc47e5029bb6a3d33cd09db69e8f3jpg/index
ERROR - 2018-08-29 07:11:03 --> 404 Page Not Found: 05977ce41e1f4e8340d68412c0f725adjpg/index
ERROR - 2018-08-29 07:11:03 --> 404 Page Not Found: Passjpg/index
ERROR - 2018-08-29 07:11:03 --> 404 Page Not Found: Superadminpng/index
ERROR - 2018-08-29 07:11:03 --> 404 Page Not Found: Dd4cc47e5029bb6a3d33cd09db69e8f3jpg/index
ERROR - 2018-08-29 07:11:04 --> 404 Page Not Found: 5a574e50649b1e7e6bafec08870cc40ejpg/index
ERROR - 2018-08-29 07:28:29 --> 404 Page Not Found: masterdata/MasterDataAdminImageGallery/05977ce41e1f4e8340d68412c0f725ad.jpg
ERROR - 2018-08-29 07:28:34 --> 404 Page Not Found: masterdata/MasterDataAdminImageGallery/05977ce41e1f4e8340d68412c0f725ad.jpg
ERROR - 2018-08-29 07:28:40 --> 404 Page Not Found: masterdata/MasterDataAdminImageGallery/05977ce41e1f4e8340d68412c0f725ad.jpg
ERROR - 2018-08-29 08:17:47 --> 404 Page Not Found: GymContent/index
