<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-02 03:17:19 --> Severity: error --> Exception: Call to undefined function site_url() C:\xampp\htdocs\admingetfit\application\views\templates\header.php 8
ERROR - 2018-08-02 03:36:05 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\admingetfit\application\views\templates\header.php 8
ERROR - 2018-08-02 03:39:20 --> Severity: error --> Exception: Call to undefined function site_url() C:\xampp\htdocs\admingetfit\application\views\templates\header.php 8
ERROR - 2018-08-02 03:40:25 --> Severity: error --> Exception: Call to undefined function site_url() C:\xampp\htdocs\admingetfit\application\views\templates\header.php 8
ERROR - 2018-08-02 03:40:26 --> Severity: error --> Exception: Call to undefined function site_url() C:\xampp\htdocs\admingetfit\application\views\templates\header.php 8
ERROR - 2018-08-02 03:41:13 --> Unable to load the requested class: Authenticator
ERROR - 2018-08-02 03:42:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Page_protector_model C:\xampp\htdocs\admingetfit\system\core\Loader.php 348
ERROR - 2018-08-02 03:46:57 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:47:00 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:47:04 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:47:46 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:47:47 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:47:48 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:48:02 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:48:42 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:48:43 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:53:46 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:53:48 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:54:05 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:54:05 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:54:08 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:56:51 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:56:53 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:57:54 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:57:55 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 03:57:55 --> 404 Page Not Found: Home/index
ERROR - 2018-08-02 04:10:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Role_management_model C:\xampp\htdocs\admingetfit\system\core\Loader.php 348
ERROR - 2018-08-02 04:11:35 --> Query error: No database selected - Invalid query: SELECT *
FROM `gymmainlogin`
WHERE `sys_id` IS NULL
ERROR - 2018-08-02 05:21:53 --> Query error: Unknown column 'sys_id' in 'where clause' - Invalid query: SELECT *
FROM `gymmainlogin`
WHERE `sys_id` IS NULL
ERROR - 2018-08-02 05:23:30 --> Query error: Unknown column 'sys_id' in 'where clause' - Invalid query: SELECT *
FROM `gymmainlogin`
WHERE `sys_id` IS NULL
ERROR - 2018-08-02 05:24:30 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:24:30 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:24:30 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:24:30 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:24:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:25:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:25:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:25:09 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:11 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:25:11 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:25:11 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:25:11 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:52 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:25:52 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:25:52 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:25:52 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:25:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:27:36 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:27:36 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:27:36 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:27:36 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:27:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:28:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:28:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:28:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:28:09 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:28:39 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:28:39 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:28:39 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:28:39 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:28:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:29:10 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:29:10 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:29:10 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:29:10 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:30:44 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:30:44 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:30:44 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:30:44 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:30:58 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:30:58 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:30:58 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:30:58 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:30:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:31:07 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:31:07 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:31:07 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:31:07 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:31:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:31:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:31:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:31:09 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:31:09 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:31:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:33:01 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:33:01 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:33:01 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:33:01 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:33:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:33:46 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 121
ERROR - 2018-08-02 05:33:46 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 127
ERROR - 2018-08-02 05:33:46 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 181
ERROR - 2018-08-02 05:33:46 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:35:50 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 05:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 207
ERROR - 2018-08-02 07:30:28 --> 404 Page Not Found: Register/mainlogin
ERROR - 2018-08-02 07:30:54 --> 404 Page Not Found: Register/index
ERROR - 2018-08-02 07:31:02 --> 404 Page Not Found: Register/index
ERROR - 2018-08-02 07:31:33 --> 404 Page Not Found: Register/index
ERROR - 2018-08-02 07:31:34 --> 404 Page Not Found: Register/index
ERROR - 2018-08-02 07:34:45 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:34:45 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:34:45 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:39:09 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:39:09 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:39:09 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:39:23 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:39:23 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:39:23 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:39:24 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:39:24 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:39:24 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:39:25 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:39:25 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:39:25 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:43:05 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:43:05 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:43:05 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:48:39 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 07:48:39 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:48:39 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:48:56 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 07:48:56 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 07:48:56 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:24:02 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:24:02 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:24:02 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:28:20 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:28:20 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:28:20 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:28:41 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:28:41 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:28:41 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:29:53 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:29:53 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:29:53 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:30:29 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:30:29 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:30:29 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:31:50 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:31:50 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:31:50 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:32:35 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:32:35 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-02 08:32:35 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:33:10 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-02 08:33:10 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-02 08:33:10 --> 404 Page Not Found: Organization_master/ajax_load_user_title
