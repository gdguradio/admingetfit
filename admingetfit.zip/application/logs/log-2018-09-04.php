<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-04 01:20:06 --> Query error: Unknown column 'HasChild' in 'field list' - Invalid query: UPDATE `masterdatagymphases` SET `PhaseName` = 'Phase 1!', `Description` = 'First Phase', `DocumentLink` = NULL, `DisplayOrderIndex` = '1', `DeleteStatus` = 'no', `PhaseStatus` = 'yes', `HasChild` = 'yes', `AddedBy` = '1', `AddedDate` = '2018-09-04'
WHERE `SysID` IS NULL
ERROR - 2018-09-04 01:23:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataGymPhase_.php 185
ERROR - 2018-09-04 01:23:15 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataGymPhase_.php 185
ERROR - 2018-09-04 01:48:32 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/subgymphaselist
ERROR - 2018-09-04 01:48:59 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/subgymphaselist
ERROR - 2018-09-04 01:49:47 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/subgymphaselist
ERROR - 2018-09-04 01:49:54 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/subgymphaselist
ERROR - 2018-09-04 01:51:10 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/subgymphaselist
ERROR - 2018-09-04 01:51:19 --> 404 Page Not Found: MasterDataSubGymPhase/index
ERROR - 2018-09-04 01:51:45 --> 404 Page Not Found: MasterDataSubGymPhase/index
ERROR - 2018-09-04 01:51:45 --> 404 Page Not Found: MasterDataSubGymPhase/index
ERROR - 2018-09-04 01:51:48 --> Severity: error --> Exception: Unable to locate the model you have specified: MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 348
ERROR - 2018-09-04 01:52:12 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:13 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:13 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:35 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:36 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:36 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/masterdata/MasterDataSubGymPhase_.php exists, but doesn't declare class MasterDataSubGymPhase_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-09-04 01:52:52 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 01:53:23 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 02:00:13 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 02:00:44 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/insertMasterDataSubGymPhaseFromAjax
ERROR - 2018-09-04 02:01:26 --> 404 Page Not Found: masterdata/MasterDataSubGymPhase/insertMasterDataSubGymPhaseFromAjax
ERROR - 2018-09-04 02:02:00 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::addSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 106
ERROR - 2018-09-04 02:03:07 --> Query error: Unknown column 'PhaseStatus' in 'field list' - Invalid query: INSERT INTO `masterdatasubgymphases` (`PhaseName`, `Description`, `DocumentLink`, `DisplayOrderIndex`, `DeleteStatus`, `PhaseStatus`, `HasSub`, `AddedBy`, `AddedDate`) VALUES (NULL, 'Phase 1 sub Phase 1', 'e48cbfc7c3d169b54bcea389fba02af2.PNG', '1', NULL, NULL, NULL, '1', '2018-09-04')
ERROR - 2018-09-04 02:05:57 --> Query error: Column 'DeleteStatus' cannot be null - Invalid query: INSERT INTO `masterdatasubgymphases` (`PhaseName`, `Description`, `DocumentLink`, `DisplayOrderIndex`, `DeleteStatus`, `SubPhaseStatus`, `maingymphaseID`, `AddedBy`, `AddedDate`) VALUES (NULL, 'Phase 1 sub Phase 1', '63b1adb377d4f642d0c9fe78d9d67f29.PNG', '1', NULL, NULL, '1', '1', '2018-09-04')
ERROR - 2018-09-04 02:06:24 --> Query error: Column 'SubPhaseStatus' cannot be null - Invalid query: INSERT INTO `masterdatasubgymphases` (`PhaseName`, `Description`, `DocumentLink`, `DisplayOrderIndex`, `DeleteStatus`, `SubPhaseStatus`, `maingymphaseID`, `AddedBy`, `AddedDate`) VALUES (NULL, 'Phase 1 sub Phase 1', 'dfa75685a50080cdfad898c48979e8b9.PNG', '1', 'no', NULL, '1', '1', '2018-09-04')
ERROR - 2018-09-04 02:06:46 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 02:06:51 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 02:07:20 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadSubGymPhase() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 52
ERROR - 2018-09-04 02:08:43 --> Severity: Notice --> Undefined property: stdClass::$HasSub C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataSubGymPhase_.php 107
ERROR - 2018-09-04 02:10:37 --> Severity: error --> Exception: Call to undefined method MasterDataSubGymPhase_::loadMainGymPhaseWithSub() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubGymPhase.php 182
ERROR - 2018-09-04 03:31:16 --> Severity: error --> Exception: Too few arguments to function ShowGymPhases_::ajaxLoadPhases(), 0 passed in C:\xampp\htdocs\admingetfit\application\controllers\gym\ShowGymPhases.php on line 22 and exactly 2 expected C:\xampp\htdocs\admingetfit\application\models\gym\ShowGymPhases_.php 4
ERROR - 2018-09-04 03:32:31 --> Severity: error --> Exception: Too few arguments to function ShowGymPhases_::ajaxLoadPhases(), 0 passed in C:\xampp\htdocs\admingetfit\application\controllers\gym\ShowGymPhases.php on line 22 and exactly 2 expected C:\xampp\htdocs\admingetfit\application\models\gym\ShowGymPhases_.php 4
ERROR - 2018-09-04 03:33:45 --> Query error: Unknown column 'B.masterdatagymphasesID' in 'on clause' - Invalid query: SELECT *, `A`.`SysID` AS `DetailsID`, `B`.`SysID` AS `sysID`
FROM `masterdatasubgymphases` as `A`
INNER JOIN `masterdatasubgymphasesshowto` as `B` ON `A`.`SysID` = `B`.`masterdatagymphasesID`
WHERE `A`.`SubPhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
AND `B`.`ShowToBranch` = '1'
AND `B`.`ShowToBranchRole` = '1'
ERROR - 2018-09-04 03:34:14 --> Query error: Unknown column 'A.MasterDataBulletinBoardDetailsID' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatagymphasesshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`MasterDataBulletinBoardDetailsID` = '1'
AND `A`.`EntryShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:37:15 --> Query error: Unknown column 'masterdatasubgymphasesA.ID' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatasubgymphases` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `masterdatasubgymphasesA`.`ID` = '1'
AND `A`.`EntryShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:37:33 --> Query error: Unknown column 'A.masterdatasubgymphasesID' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatasubgymphases` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatasubgymphasesID` = '1'
AND `A`.`EntryShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:40:07 --> Query error: Unknown column 'A.EntryShowToBranch' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatasubgymphasesshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatasubgymphasesID` = '1'
AND `A`.`EntryShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`EntryStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:40:53 --> Query error: Unknown column 'A.EntryShowToBranch' in 'on clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatasubgymphasesshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatasubgymphasesID` = '1'
AND `A`.`ShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`SubPhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:41:10 --> Query error: Unknown column 'A.masterdatagymphasesID' in 'where clause' - Invalid query: SELECT DISTINCT `RoleName`, `C`.`SysID` AS `roleID`
FROM `masterdatasubgymphases` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`ShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatagymphasesID` = '1'
AND `A`.`ShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`PhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-04 03:42:24 --> Query error: Unknown column 'A.masterdatagymphasesID' in 'where clause' - Invalid query: SELECT DISTINCT `RoleName`, `C`.`SysID` AS `roleID`
FROM `masterdatasubgymphases` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`ShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatagymphasesID` = '1'
AND `A`.`ShowToBranch` = '1'
AND `A`.`ShowToBranchRole` = '1'
AND `A`.`PhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
