<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-08 00:30:17 --> 404 Page Not Found: masterdata/MasterDataMenu/ajaxLoadSubMenu
ERROR - 2018-08-08 00:30:20 --> 404 Page Not Found: masterdata/MasterDataMenu/ajaxLoadSubMenu
ERROR - 2018-08-08 00:31:00 --> Query error: Table 'getfit.masterdatasubmenu' doesn't exist - Invalid query: SELECT `A`.*
FROM `masterdatasubmenu` as `A`
ERROR - 2018-08-08 00:35:14 --> Severity: Notice --> Undefined property: MasterDataSubMenu::$rm C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 68
ERROR - 2018-08-08 00:35:14 --> Severity: error --> Exception: Call to a member function submenu_type_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 68
ERROR - 2018-08-08 00:35:55 --> Severity: error --> Exception: Call to undefined method MasterDataSubMenu_::add_submenu() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 71
ERROR - 2018-08-08 00:41:28 --> Query error: Unknown column 'Description' in 'field list' - Invalid query: INSERT INTO `masterdatasubmenu` (`SubMenuName`, `Description`) VALUES ('Data Management', 'Data Management')
ERROR - 2018-08-08 00:51:49 --> Query error: Column 'MenuNameID' cannot be null - Invalid query: INSERT INTO `masterdatasubmenu` (`SubMenuName`, `Description`, `HasChild`, `Link`, `FaIcon`, `MenuNameID`) VALUES ('Data Management', 'Data Menu', 'yes', 'MasterDataSubMenu/submenulist', '', NULL)
ERROR - 2018-08-08 01:07:53 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 01:09:47 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 01:10:07 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 01:35:05 --> 404 Page Not Found: masterdata/MasterDataScreen/loadmenu
ERROR - 2018-08-08 01:35:06 --> 404 Page Not Found: masterdata/MasterDataScreen/loadmenu
ERROR - 2018-08-08 01:35:06 --> 404 Page Not Found: masterdata/MasterDataScreen/loadmenu
ERROR - 2018-08-08 01:35:06 --> 404 Page Not Found: masterdata/MasterDataScreen/loadmenu
ERROR - 2018-08-08 01:35:52 --> 404 Page Not Found: masterdata/MasterDataScreen/loadmenu
ERROR - 2018-08-08 01:35:52 --> 404 Page Not Found: masterdata/MasterDataScreen/loadsubmenu
ERROR - 2018-08-08 01:35:52 --> 404 Page Not Found: masterdata/MasterDataScreen/loadlink
ERROR - 2018-08-08 02:32:24 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 02:33:08 --> Query error: Table 'getfit.masterdatascreen' doesn't exist - Invalid query: SELECT `A`.*
FROM `masterdatascreen` as `A`
ERROR - 2018-08-08 02:42:18 --> Severity: Notice --> Undefined property: MasterDataScreen::$rm C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataScreen.php 84
ERROR - 2018-08-08 02:42:18 --> Severity: error --> Exception: Call to a member function screentype_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataScreen.php 84
ERROR - 2018-08-08 02:43:35 --> Severity: error --> Exception: Call to undefined method MasterDataScreen_::screentype_checker() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataScreen.php 84
ERROR - 2018-08-08 02:43:53 --> Severity: error --> Exception: Call to undefined method MasterDataScreen_::add_screen() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataScreen.php 87
ERROR - 2018-08-08 02:46:36 --> Severity: error --> Exception: Call to undefined method MasterDataScreen_::add_screen() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataScreen.php 87
ERROR - 2018-08-08 03:34:33 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 03:34:41 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 03:38:30 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-08 05:09:40 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 93
ERROR - 2018-08-08 05:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 93
ERROR - 2018-08-08 05:11:21 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 93
ERROR - 2018-08-08 05:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 93
ERROR - 2018-08-08 05:12:03 --> Severity: Notice --> Undefined variable: has_child C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 20
ERROR - 2018-08-08 05:12:03 --> Severity: Notice --> Undefined variable: menu_id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 41
ERROR - 2018-08-08 05:12:03 --> Severity: Notice --> Undefined variable: menu_id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 41
ERROR - 2018-08-08 05:12:03 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:12:03 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:12:35 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:13:29 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:13:29 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:14:24 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:14:24 --> Severity: Notice --> Undefined property: stdClass::$has_child C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:14:55 --> Severity: Notice --> Undefined property: stdClass::$haschild C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:14:55 --> Severity: Notice --> Undefined property: stdClass::$haschild C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 98
ERROR - 2018-08-08 05:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 99
ERROR - 2018-08-08 05:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 99
ERROR - 2018-08-08 08:14:08 --> Severity: error --> Exception: Call to undefined method MasterDataRole_::addRole() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataRole.php 54
ERROR - 2018-08-08 08:14:28 --> Query error: Unknown column 'ItemNmber' in 'field list' - Invalid query: INSERT INTO `masterdatarolemapping` (`Access`, `ItemLevel`, `ItemLink`, `ItemNmber`, `ItemSysID`, `MasterDataRoleID`) VALUES ('3','menu','','menu_1','1',1), ('3','submenu','MasterDataSubMenu/submenulist','submenu_1','1',1), ('3','screen','MasterDataScreen/screenlist','screen_1','1',1), ('3','submenu','','submenu_2','2',1), ('3','screen','MasterDataScreen/screenlist','screen_2','2',1), ('3','menu','','menu_2','2',1)
ERROR - 2018-08-08 08:52:25 --> Severity: error --> Exception: Call to undefined method MasterDataRole_::load_menu() C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 7
