<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-09 00:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 94
ERROR - 2018-08-09 00:57:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 94
ERROR - 2018-08-09 00:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 94
ERROR - 2018-08-09 01:28:41 --> 404 Page Not Found: Index2html/index
ERROR - 2018-08-09 02:26:14 --> Query error: Unknown column 'link' in 'where clause' - Invalid query: SELECT `Access`
FROM `masterdatarolemapping`
WHERE `link` = 'Welcome'
ERROR - 2018-08-09 02:26:49 --> Query error: Unknown column 'Link' in 'where clause' - Invalid query: SELECT `Access`
FROM `masterdatarolemapping`
WHERE `Link` = 'Welcome'
ERROR - 2018-08-09 02:28:09 --> 404 Page Not Found: Home/index
ERROR - 2018-08-09 02:28:15 --> 404 Page Not Found: Home/index
ERROR - 2018-08-09 02:29:08 --> 404 Page Not Found: Home/index
ERROR - 2018-08-09 02:52:08 --> 404 Page Not Found: Register/searchRoleFromAjax
ERROR - 2018-08-09 02:56:59 --> 404 Page Not Found: Register/searchRoleFromAjax
ERROR - 2018-08-09 03:48:09 --> Severity: Notice --> Undefined variable: phptime C:\xampp\htdocs\admingetfit\application\controllers\registeruser\MainUserInformation.php 118
ERROR - 2018-08-09 06:22:51 --> 404 Page Not Found: Register/loadMainGymInformation
ERROR - 2018-08-09 06:30:01 --> 404 Page Not Found: Register/loadMainGymInformation
ERROR - 2018-08-09 08:34:01 --> 404 Page Not Found: registerbranch/MainGymInformation/maingymlist
ERROR - 2018-08-09 08:41:34 --> 404 Page Not Found: registerbranch/MainGymInformation/ajaxLoadBranch
ERROR - 2018-08-09 08:41:34 --> Query error: Table 'getfit.maingymlogin' doesn't exist - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `maingymlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:42:18 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:45:17 --> 404 Page Not Found: Getfit247/assets
ERROR - 2018-08-09 08:46:00 --> 404 Page Not Found: registerbranch/MainGymInformation/ajaxLoadBranch
ERROR - 2018-08-09 08:46:00 --> Query error: Table 'getfit.maingymlogin' doesn't exist - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `maingymlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:46:12 --> 404 Page Not Found: registerbranch/MainGymInformation/ajaxLoadBranch
ERROR - 2018-08-09 08:47:02 --> Query error: Table 'getfit.maingymlogin' doesn't exist - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `maingymlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:47:02 --> Query error: Table 'getfit.maingymlogin' doesn't exist - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `maingymlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:47:34 --> Query error: Unknown column 'A.BranhDetailsID' in 'on clause' - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:47:34 --> Query error: Unknown column 'A.BranhDetailsID' in 'on clause' - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`BranhDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:47:47 --> Query error: Unknown column 'A.BranchDetailsID' in 'on clause' - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`BranchDetailsID`
WHERE `BranchType` = 'main'
ERROR - 2018-08-09 08:47:47 --> Query error: Unknown column 'A.BranchDetailsID' in 'on clause' - Invalid query: SELECT `A`.*, `B`.`SysID` AS `maingymloginID`, `A`.`SysID` As `mainbranchID`
FROM `Branchdetails` as `A`
JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`BranchDetailsID`
WHERE `BranchType` = 'main'
