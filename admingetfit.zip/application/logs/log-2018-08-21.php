<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-21 00:12:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 191
ERROR - 2018-08-21 00:12:11 --> Severity: Notice --> Undefined variable: menu_type C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 192
ERROR - 2018-08-21 00:12:11 --> Severity: Notice --> Undefined variable: last_id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 165
ERROR - 2018-08-21 00:12:11 --> Query error: Unknown column 'MasterDataBulletinBoardDetailsID' in 'where clause' - Invalid query: DELETE FROM `masterdatabulletinboarddetails`
WHERE `MasterDataBulletinBoardDetailsID` = '1'
ERROR - 2018-08-21 00:12:38 --> Severity: Notice --> Undefined variable: menu_type C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 192
ERROR - 2018-08-21 00:12:38 --> Severity: Notice --> Undefined variable: last_id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 165
ERROR - 2018-08-21 00:12:38 --> Query error: Unknown column 'MasterDataBulletinBoardDetailsID' in 'where clause' - Invalid query: DELETE FROM `masterdatabulletinboarddetails`
WHERE `MasterDataBulletinBoardDetailsID` = '1'
ERROR - 2018-08-21 00:15:00 --> Severity: Notice --> Undefined variable: last_id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 165
ERROR - 2018-08-21 00:15:00 --> Query error: Unknown column 'MasterDataBulletinBoardDetailsID' in 'where clause' - Invalid query: DELETE FROM `masterdatabulletinboarddetails`
WHERE `MasterDataBulletinBoardDetailsID` = '1'
ERROR - 2018-08-21 00:16:10 --> Query error: Unknown column 'MasterDataBulletinBoardDetailsID' in 'where clause' - Invalid query: DELETE FROM `masterdatabulletinboarddetails`
WHERE `MasterDataBulletinBoardDetailsID` = '1'
ERROR - 2018-08-21 00:17:08 --> Query error: Unknown column 'EntryShowToBranch' in 'field list' - Invalid query: INSERT INTO `masterdatarolemapping` (`AddedBy`, `AddedDate`, `DeleteStatus`, `EntryShowToBranch`, `EntryStatus`, `MasterDataBulletinBoardDetailsID`, `ShowToBranchRole`) VALUES ('1','2018-08-21','yes','1','no','1','1')
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: %7B/index
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: S/index
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: D/index
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: S/index
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: Y/index
ERROR - 2018-08-21 03:24:53 --> 404 Page Not Found: I/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: %7B/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: Y/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: S/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: S/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: I/index
ERROR - 2018-08-21 03:25:25 --> 404 Page Not Found: D/index
ERROR - 2018-08-21 03:33:36 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:34:02 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:37:52 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:38:17 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:41:39 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:42:19 --> 404 Page Not Found: Masterdatabulletinboard/index
ERROR - 2018-08-21 03:52:17 --> Query error: Unknown column 'Null' in 'field list' - Invalid query: SELECT DISTINCT *, `Null` AS `Password`
FROM `masterdatabulletinboarddetails` AS `A`
INNER JOIN `gymmainlogin` as `B` ON `B`.`SysID` = `A`.`EntryFrom`
WHERE `A`.`EntryFrom` = '2'
ERROR - 2018-08-21 03:57:50 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\views\index.php 322
ERROR - 2018-08-21 04:02:12 --> 404 Page Not Found: Assets/UserPhoto
