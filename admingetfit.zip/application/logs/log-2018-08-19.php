<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-19 23:59:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 19
ERROR - 2018-08-19 23:59:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 19
