<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-15 02:56:32 --> Query error: Column 'UserPhoto' cannot be null - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `PositionID`, `MasterDataRoleID`, `UserPhoto`, `AddedBy`, `AddedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('User', '', 'User', '', 'user', '$2y$10$OAcQ.XsGEUmoM1clYcO0cenku6cITrjhPQCPZAEBplLV0J6wMQiVy', 'user@gmail.com', NULL, '', '1', '1', '1', NULL, '1', '2018-08-15', 'yes', 'no')
ERROR - 2018-08-15 02:57:41 --> Query error: Column 'UserPhoto' cannot be null - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `PositionID`, `MasterDataRoleID`, `UserPhoto`, `AddedBy`, `AddedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('User', '', 'User', '', 'user', '$2y$10$4hL.LzyPttobGCdSUEj2HuNCcv7d90I3GgkRGUFCZuRtw9ZzcqYJW', 'user@gmail.com', NULL, '', '1', '1', '1', NULL, '1', '2018-08-15', 'yes', 'no')
ERROR - 2018-08-15 03:36:56 --> 404 Page Not Found: UserProfile/user
ERROR - 2018-08-15 03:37:00 --> 404 Page Not Found: UserProfile/user
ERROR - 2018-08-15 03:37:00 --> 404 Page Not Found: UserProfile/user
ERROR - 2018-08-15 03:37:09 --> 404 Page Not Found: UserProfile/user
ERROR - 2018-08-15 03:40:35 --> 404 Page Not Found: UserProfile/user
ERROR - 2018-08-15 03:41:34 --> 404 Page Not Found: UserProfile/userProfile
ERROR - 2018-08-15 03:50:36 --> 404 Page Not Found: UserProfile/userProfile
ERROR - 2018-08-15 03:54:07 --> 404 Page Not Found: UserProfile/userProfile
ERROR - 2018-08-15 03:55:41 --> 404 Page Not Found: UserProfile/userProfile
ERROR - 2018-08-15 03:59:41 --> 404 Page Not Found: UserProfile/userProfile
ERROR - 2018-08-15 03:59:48 --> Query error: Table 'getfit.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `SysID` = '1'
ERROR - 2018-08-15 04:00:13 --> Severity: Notice --> Undefined property: stdClass::$fname C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 04:00:13 --> Severity: Notice --> Undefined property: stdClass::$lname C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:19:32 --> 404 Page Not Found: Register/UserProfile
ERROR - 2018-08-15 05:20:41 --> 404 Page Not Found: Register/UserProfile
ERROR - 2018-08-15 05:20:49 --> 404 Page Not Found: Register/UserProfile
ERROR - 2018-08-15 05:22:04 --> Severity: error --> Exception: Too few arguments to function UserProfile::userProfile(), 0 passed in C:\xampp\htdocs\admingetfit\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\admingetfit\application\controllers\registeruser\UserProfile.php 10
ERROR - 2018-08-15 05:22:22 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:22:22 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:22:22 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 05:28:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`Password`
FROM `gymmainlogin` as `A`
LEFT JOIN `masterdatarole` as `B` ON `B`.' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, `null` AS `A`.`Password`
FROM `gymmainlogin` as `A`
LEFT JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
LEFT JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
LEFT JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:28:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`Password`
FROM `gymmainlogin` as `A`
LEFT JOIN `masterdatarole` as `B` ON `B`.' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, `NULL` AS `A`.`Password`
FROM `gymmainlogin` as `A`
LEFT JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
LEFT JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
LEFT JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:29:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`Password`
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, `NULL` AS `A`.`Password`
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
INNER JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:32:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, 'NULL' AS A.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
INNER JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:32:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, 'NULL' AS A.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
INNER JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:32:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, 'NULL' AS A.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
INNER JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:32:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`' at line 1 - Invalid query: SELECT `A`.*, `B`.`RoleName`, `C`.`Positionname`, `D`.*, `A`.`SysID` AS `loginSysID`, `D`.`SysID` AS `branchSysID`, 'NULL' AS A.Password
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`. `MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`SysID` = `A`.`PositionID`
INNER JOIN `branchdetails` as `D` ON `D`.`SysID` = `A`.`BranchDetailsID`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-15 05:37:26 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:37:26 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:37:26 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 05:42:40 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:42:40 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:42:40 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 05:43:44 --> Severity: Notice --> Trying to get property 'FirstName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:43:44 --> Severity: Notice --> Trying to get property 'LastName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:43:44 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 05:44:03 --> Severity: Warning --> Use of undefined constant FirstName - assumed 'FirstName' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:44:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:44:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:44:03 --> Severity: Warning --> Use of undefined constant LastName - assumed 'LastName' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 28
ERROR - 2018-08-15 05:44:03 --> Severity: Warning --> Use of undefined constant RoleName - assumed 'RoleName' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 05:44:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\application\views\registeruser\userprofile.php 30
ERROR - 2018-08-15 07:57:29 --> 404 Page Not Found: AdminImageGallery/imagelist
ERROR - 2018-08-15 08:03:42 --> 404 Page Not Found: AdminImageGallery/imagelist
ERROR - 2018-08-15 08:03:52 --> 404 Page Not Found: AdminImageGallery/imagelist
ERROR - 2018-08-15 08:04:43 --> Severity: error --> Exception: Unable to locate the model you have specified: AdminImageGallery_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 348
