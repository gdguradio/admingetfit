<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-20 00:00:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 40
ERROR - 2018-08-20 00:01:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 19
ERROR - 2018-08-20 00:02:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:03:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:03:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:04:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:04:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:04:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:11:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:11:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:12:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:14:11 --> Severity: Notice --> Undefined variable: os C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 42
ERROR - 2018-08-20 00:14:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 42
ERROR - 2018-08-20 00:14:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 00:55:16 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 42
ERROR - 2018-08-20 00:55:16 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 42
ERROR - 2018-08-20 00:57:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-20 05:26:38 --> 404 Page Not Found: masterdata/MasterDataMenu/insertMasterDataBulletinBoardFromAjax
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 96
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 97
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 98
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 99
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 100
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 101
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 96
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 97
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 98
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 99
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 100
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 101
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 96
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 97
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 98
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 99
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 100
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 101
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 96
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 97
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 98
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 99
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 100
ERROR - 2018-08-20 05:28:09 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 101
ERROR - 2018-08-20 06:13:27 --> Severity: Notice --> Undefined variable: arr1 C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:13:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:13:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:14:07 --> Severity: Notice --> Undefined index: EntryTitle C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:14:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:14:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:14:20 --> Severity: Notice --> Undefined index: EntryTitle C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:14:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:14:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:14:49 --> Severity: Notice --> Undefined index: EntryTitle C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:14:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:14:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:15:08 --> Severity: Warning --> Use of undefined constant details - assumed 'details' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 132
ERROR - 2018-08-20 06:15:08 --> Severity: Notice --> Undefined index: EntryTitle C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:15:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:15:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:15:17 --> Severity: Notice --> Undefined index: EntryTitle C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 133
ERROR - 2018-08-20 06:15:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\admingetfit\system\database\DB_driver.php 1477
ERROR - 2018-08-20 06:15:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `masterdatabulletinboarddetails` (0) VALUES (Array)
ERROR - 2018-08-20 06:16:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 120
ERROR - 2018-08-20 06:16:44 --> Severity: Notice --> Undefined variable: entrytype C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 122
ERROR - 2018-08-20 06:16:44 --> Severity: Notice --> Undefined variable: entrytitle C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 123
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entryfrom C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 124
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 125
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 120
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytype C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 122
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytitle C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 123
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entryfrom C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 124
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 125
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 120
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytype C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 122
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytitle C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 123
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entryfrom C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 124
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 125
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 120
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytype C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 122
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entrytitle C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 123
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: entryfrom C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 124
ERROR - 2018-08-20 06:16:45 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 125
ERROR - 2018-08-20 06:47:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `SysID` = '1'' at line 4 - Invalid query: SELECT *, `B`.`BranchName`, `C`.`RoleName`
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
JOIN `masterdatarole` as `C`.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `SysID` = '1'
ERROR - 2018-08-20 06:48:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `A`.`SysID` = '1'' at line 4 - Invalid query: SELECT `A`.*, `B`.`BranchName`, `C`.`RoleName`
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
JOIN `masterdatarole` as `C`.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-20 06:54:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `A`.`SysID` = '1'' at line 4 - Invalid query: SELECT `A`.*
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
JOIN `masterdatarole` as `C`.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-20 06:54:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`SysID = A`.`EntryShowToBranch` USING (`inner`)
JOIN `masterdatarole` as `C`.`S' at line 3 - Invalid query: SELECT `A`.*, `B`.`BranchName`, `C`.`RoleName`
FROM `masterdatabulletinboard` AS `A`
JOIN `branchdetails` as `B`.`SysID = A`.`EntryShowToBranch` USING (`inner`)
JOIN `masterdatarole` as `C`.`SysID = A`.`ShowToBranchRole` USING (`inner`)
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-20 07:02:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 116
ERROR - 2018-08-20 07:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 294
ERROR - 2018-08-20 07:02:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 116
ERROR - 2018-08-20 07:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\system\database\DB_query_builder.php 294
ERROR - 2018-08-20 07:02:30 --> Query error: Column 'SysID' in field list is ambiguous - Invalid query: SELECT `BranchName`, `SysID` AS `BranchID`
FROM `masterdatabulletinboard` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`SysID` = '1'
ERROR - 2018-08-20 08:13:25 --> Severity: error --> Exception: Too few arguments to function MasterDataBulletinBoard_::getbullenshowto_byid(), 1 passed in C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php on line 101 and exactly 2 expected C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 127
