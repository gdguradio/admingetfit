<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-07 00:02:01 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:02:03 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:02:03 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:02:04 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:02:13 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:02:18 --> Severity: error --> Exception: Unable to locate the model you have specified: MasterDataMenu_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 348
ERROR - 2018-08-07 00:05:14 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:05:17 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:05:21 --> 404 Page Not Found: masterdata/MasterDataSubMenu/submenulist
ERROR - 2018-08-07 00:06:12 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:06:57 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:09:46 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:10:24 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:10:38 --> 404 Page Not Found: masterdata/MasterDataSubMenu/submenulist
ERROR - 2018-08-07 00:20:07 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:20:12 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:20:18 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:20:46 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:33:42 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:33:46 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:33:49 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:35:43 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:35:45 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:35:47 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:36:41 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:36:41 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:36:43 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 00:36:45 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 02:02:48 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 02:02:50 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 02:03:59 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 02:39:46 --> 404 Page Not Found: Masterdatamenu/loadlink
ERROR - 2018-08-07 02:44:28 --> 404 Page Not Found: Masterdatamenu/loadlink
ERROR - 2018-08-07 02:45:16 --> 404 Page Not Found: masterdata/Loadlink/index
ERROR - 2018-08-07 02:45:46 --> Severity: Notice --> Undefined property: MasterDataMenu::$load C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 02:45:46 --> Severity: error --> Exception: Call to a member function helper() on null C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 02:49:16 --> Severity: Notice --> Undefined property: MasterDataMenu::$load C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 02:49:16 --> Severity: error --> Exception: Call to a member function helper() on null C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 02:49:28 --> Severity: Notice --> Undefined property: MasterDataMenu::$load C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 02:49:28 --> Severity: error --> Exception: Call to a member function helper() on null C:\xampp\htdocs\admingetfit\system\libraries\Form_validation.php 147
ERROR - 2018-08-07 03:27:43 --> 404 Page Not Found: Masterdatarole/MasterDataMenu
ERROR - 2018-08-07 03:27:55 --> 404 Page Not Found: Masterdatarole/MasterDataMenu
ERROR - 2018-08-07 04:01:15 --> 404 Page Not Found: Masterdatarole/MasterDataMenu
ERROR - 2018-08-07 05:57:04 --> Severity: Notice --> Undefined index: menuname C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataMenu.php 53
ERROR - 2018-08-07 05:57:13 --> Severity: Notice --> Undefined index: menuname C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataMenu.php 53
ERROR - 2018-08-07 07:34:53 --> Severity: error --> Exception: Too few arguments to function MasterDataMenu_::updateMenu(), 1 passed in C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataMenu.php on line 78 and exactly 2 expected C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataMenu_.php 24
ERROR - 2018-08-07 07:37:43 --> Query error: Table 'getfit.af_menu' doesn't exist - Invalid query: UPDATE `af_menu` SET `MenuName` = 'Master Data Management!', `Description` = 'Main Master Data', `HasChild` = 'yes', `Link` = '', `FaIcon` = 'fa fa-dashboard'
WHERE `sys_id` = ''
ERROR - 2018-08-07 07:42:37 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:44:09 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:44:58 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:50:57 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:51:54 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:52:04 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:52:05 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:53:04 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:53:09 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:53:14 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 07:53:37 --> 404 Page Not Found: Masterdatarole/MasterDataRole
ERROR - 2018-08-07 08:19:27 --> 404 Page Not Found: Masterdatasubmenu/MasterDataSubmenu
ERROR - 2018-08-07 08:28:11 --> Severity: Warning --> array_slice() expects parameter 1 to be array, null given C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 32
ERROR - 2018-08-07 08:29:19 --> Severity: Warning --> array_slice() expects parameter 1 to be array, null given C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 32
ERROR - 2018-08-07 08:41:51 --> Severity: Warning --> array_slice() expects at least 2 parameters, 1 given C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataSubMenu.php 42
