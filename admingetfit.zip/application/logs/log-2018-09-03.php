<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-03 03:46:01 --> 404 Page Not Found: masterdata/MasterDataGymPhase/loadBranch
ERROR - 2018-09-03 03:46:41 --> Severity: error --> Exception: Call to undefined method MasterDataGymPhase_::selectBranches() C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataGymPhase_.php 7
ERROR - 2018-09-03 03:47:29 --> Severity: error --> Exception: Call to undefined method MasterDataGymPhase_::distinctBranchRole() C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataGymPhase_.php 43
ERROR - 2018-09-03 03:48:05 --> Severity: error --> Exception: Call to undefined method MasterDataGymPhase_::selectRoleNames() C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataGymPhase_.php 46
ERROR - 2018-09-03 03:57:23 --> Query error: Column 'PositionStatus' cannot be null - Invalid query: INSERT INTO `masterdataposition` (`PositionName`, `Description`, `PositionStatus`, `DeleteStatus`, `AddedBy`, `AddedDate`) VALUES (NULL, '', NULL, NULL, '1', '2018-09-03')
ERROR - 2018-09-03 05:53:24 --> Severity: Notice --> Undefined variable: displayorder C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 71
ERROR - 2018-09-03 05:53:24 --> Severity: Notice --> Undefined variable: gymphasedeletestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 72
ERROR - 2018-09-03 05:53:24 --> Severity: Notice --> Undefined variable: gymphaseactivitystatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 73
ERROR - 2018-09-03 05:53:24 --> Severity: Notice --> Undefined variable: showtobranchrole C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:53:24 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:53:24 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:54:00 --> Severity: Notice --> Undefined variable: gymphasedeletestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 72
ERROR - 2018-09-03 05:54:00 --> Severity: Notice --> Undefined variable: gymphaseactivitystatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 73
ERROR - 2018-09-03 05:54:00 --> Severity: Notice --> Undefined variable: showtobranchrole C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:54:00 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:54:00 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:55:17 --> Severity: Notice --> Undefined variable: showtobranchrole C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:55:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 76
ERROR - 2018-09-03 05:55:17 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:55:17 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 94
ERROR - 2018-09-03 05:56:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 78
ERROR - 2018-09-03 05:56:07 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 96
ERROR - 2018-09-03 05:56:07 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 96
ERROR - 2018-09-03 05:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 80
ERROR - 2018-09-03 05:56:26 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 98
ERROR - 2018-09-03 05:56:26 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 98
ERROR - 2018-09-03 05:57:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 82
ERROR - 2018-09-03 05:57:44 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 100
ERROR - 2018-09-03 05:57:44 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 100
ERROR - 2018-09-03 05:58:13 --> Severity: Notice --> Undefined variable: bulletinboardstatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 86
ERROR - 2018-09-03 05:58:13 --> Severity: Notice --> Undefined variable: deletestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 87
ERROR - 2018-09-03 05:58:13 --> Severity: Notice --> Undefined variable: bulletinboardstatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 86
ERROR - 2018-09-03 05:58:13 --> Severity: Notice --> Undefined variable: deletestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 87
ERROR - 2018-09-03 05:58:13 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 05:58:13 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 05:59:07 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 05:59:07 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 05:59:57 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 05:59:57 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:13 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:13 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:19 --> Severity: Notice --> Undefined property: MasterDataGymPhase::$adminimagegallery C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:19 --> Severity: error --> Exception: Call to a member function duplicate_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:39 --> Severity: Notice --> Undefined variable: phodocumentto C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 99
ERROR - 2018-09-03 06:00:39 --> Severity: Notice --> Undefined variable: data_input C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 102
ERROR - 2018-09-03 06:00:55 --> Severity: Notice --> Undefined variable: data_input C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataGymPhase.php 102
ERROR - 2018-09-03 06:03:20 --> Query error: Unknown column 'EntryShowToBranch' in 'field list' - Invalid query: INSERT INTO `masterdatagymphasesshowto` (`AddedBy`, `AddedDate`, `DeleteStatus`, `EntryShowToBranch`, `PhaseStatus`, `ShowToBranchRole`, `masterdatagymphasesID`) VALUES ('1','2018-09-03','no','1','yes','1',1), ('1','2018-09-03','no','1','yes','2',1)
ERROR - 2018-09-03 06:16:24 --> Query error: Table 'getfit1.loadgymphase' doesn't exist - Invalid query: SELECT *
FROM `loadGymPhase`
WHERE `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-09-03 06:17:04 --> Query error: Unknown column 'EntryStatus' in 'where clause' - Invalid query: SELECT *
FROM `masterdatagymphases`
WHERE `EntryStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-09-03 06:17:19 --> Query error: Unknown column 'A.masterdatagymphasesID' in 'where clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatagymphases` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatagymphasesID` = '2'
AND `A`.`PhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
ERROR - 2018-09-03 06:17:47 --> Query error: Unknown column 'A.EntryShowToBranch' in 'on clause' - Invalid query: SELECT DISTINCT `BranchName`, `B`.`SysID` AS `BranchID`
FROM `masterdatagymphasesshowto` AS `A`
INNER JOIN `branchdetails` as `B` ON `B`.`SysID` = `A`.`EntryShowToBranch`
INNER JOIN `masterdatarole` as `C` ON `C`.`SysID` = `A`.`ShowToBranchRole`
WHERE `A`.`masterdatagymphasesID` = '2'
AND `A`.`PhaseStatus` = 'yes'
AND `A`.`DeleteStatus` = 'no'
