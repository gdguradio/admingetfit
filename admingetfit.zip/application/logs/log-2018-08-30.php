<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-30 02:10:17 --> 404 Page Not Found: gym/GymContent/index
ERROR - 2018-08-30 02:10:33 --> 404 Page Not Found: gym/GymContent/index
ERROR - 2018-08-30 02:15:46 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/gym/GymContent_.php exists, but doesn't declare class GymContent_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-08-30 02:15:46 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/gym/GymContent_.php exists, but doesn't declare class GymContent_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-08-30 02:16:31 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/gym/GymContent_.php exists, but doesn't declare class GymContent_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-08-30 02:16:31 --> Severity: error --> Exception: C:\xampp\htdocs\admingetfit\application\models/gym/GymContent_.php exists, but doesn't declare class GymContent_ C:\xampp\htdocs\admingetfit\system\core\Loader.php 340
ERROR - 2018-08-30 02:27:50 --> Query error: Unknown column 'PromoName' in 'field list' - Invalid query: INSERT INTO `gymcontentbenefit` (`PromoName`, `BenefitDescription`, `BenefitCategory`, `BenefitStatus`, `DeleteStatus`, `AddedBy`, `AddedDate`) VALUES ('Strength/Free Weights', 'Strength/Free Weights', '1', 'yes', 'no', '1', '2018-08-30')
ERROR - 2018-08-30 02:29:36 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-30 02:29:37 --> 404 Page Not Found: GymContentPromo/index
ERROR - 2018-08-30 02:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 56
ERROR - 2018-08-30 02:29:47 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 65
ERROR - 2018-08-30 02:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentBenefit_.php 70
ERROR - 2018-08-30 03:15:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 54
ERROR - 2018-08-30 03:15:19 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 63
ERROR - 2018-08-30 03:15:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentBenefit_.php 68
ERROR - 2018-08-30 03:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 54
ERROR - 2018-08-30 03:16:06 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 63
ERROR - 2018-08-30 03:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentBenefit_.php 68
ERROR - 2018-08-30 03:16:38 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentBenefit.php 66
ERROR - 2018-08-30 03:16:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentBenefit_.php 68
ERROR - 2018-08-30 03:17:01 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-08-30 03:17:16 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2018-08-30 03:17:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 57
ERROR - 2018-08-30 03:17:28 --> Severity: Notice --> Undefined variable: data_show C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentPromo.php 66
ERROR - 2018-08-30 03:17:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\models\gym\GymContentPromo_.php 69
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/1.png
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/2.png
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/3.png
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/4.png
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/5.png
ERROR - 2018-08-30 03:34:47 --> 404 Page Not Found: Images/6.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/1.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/2.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/3.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/6.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/5.png
ERROR - 2018-08-30 03:37:53 --> 404 Page Not Found: Images/4.png
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:29 --> 404 Page Not Found: Assets/images
ERROR - 2018-08-30 03:40:52 --> 404 Page Not Found: Assets/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 04:02:11 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 05:09:30 --> 404 Page Not Found: Images/browsers
ERROR - 2018-08-30 06:05:08 --> Severity: Notice --> Undefined property: GymContentFaqs::$gymcontentbenefit C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentFaqs.php 29
ERROR - 2018-08-30 06:05:08 --> Severity: error --> Exception: Call to a member function loadAllFaqs() on null C:\xampp\htdocs\admingetfit\application\controllers\gym\GymContentFaqs.php 29
ERROR - 2018-08-30 08:44:43 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT `A`.`SysID` AS `submenuID`, `B`.`sysID` AS `menuID`, `A`.`SubMenuName`
FROM `masterdatasubmenu` as `A`
INNER JOIN `masterdatamenu` as `B` ON `B`.`SysID` = `A`.`MenuNameID`
WHERE `A`.`MenuNameID` = '3'
AND `SubmenuStatus` = 'yes'
AND `DeleteStatus` = 'no'
ERROR - 2018-08-30 08:45:54 --> Query error: Column 'DeleteStatus' in where clause is ambiguous - Invalid query: SELECT `A`.`SysID` AS `submenuID`, `B`.`sysID` AS `menuID`, `A`.`SubMenuName`
FROM `masterdatasubmenu` as `A`
INNER JOIN `masterdatamenu` as `B` ON `B`.`SysID` = `A`.`MenuNameID`
WHERE `SubmenuStatus` = 'yes'
AND `DeleteStatus` = 'no'
