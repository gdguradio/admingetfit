<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-13 00:29:38 --> Query error: Table 'getfit.masterdatasubmenu' doesn't exist - Invalid query: SELECT *
FROM `masterdatasubmenu`
WHERE `MenuNameID` = '2'
ERROR - 2018-08-13 00:29:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-08-13 00:29:39 --> Query error: Table 'getfit.masterdatasubmenu' doesn't exist - Invalid query: SELECT *
FROM `masterdatasubmenu`
WHERE `MenuNameID` = '2'
ERROR - 2018-08-13 00:38:31 --> Severity: Notice --> Undefined property: stdClass::$Access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 15
ERROR - 2018-08-13 00:42:03 --> Severity: Notice --> Undefined property: stdClass::$Access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 15
ERROR - 2018-08-13 00:43:51 --> Severity: Notice --> Undefined property: stdClass::$Access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 15
ERROR - 2018-08-13 00:44:30 --> Severity: Notice --> Undefined property: stdClass::$Access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 15
ERROR - 2018-08-13 01:18:57 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:18:57 --> Severity: error --> Exception: Call to a member function has_access() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:19:28 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:19:28 --> Severity: error --> Exception: Call to a member function has_access() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:33:24 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:33:24 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 116
ERROR - 2018-08-13 01:37:46 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:37:46 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:04 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:04 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:22 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:22 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:47 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:39:47 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:40:05 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:40:05 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:41:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 115
ERROR - 2018-08-13 01:41:09 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 01:41:09 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 117
ERROR - 2018-08-13 02:00:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 110
ERROR - 2018-08-13 02:00:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 110
ERROR - 2018-08-13 02:06:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 110
ERROR - 2018-08-13 02:06:33 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 112
ERROR - 2018-08-13 02:06:33 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 112
ERROR - 2018-08-13 02:07:07 --> Severity: Notice --> Undefined property: MasterDataRole::$menu C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 112
ERROR - 2018-08-13 02:07:07 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 112
ERROR - 2018-08-13 02:15:00 --> Severity: Notice --> Undefined variable: model_obj C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 6
ERROR - 2018-08-13 02:15:00 --> Severity: error --> Exception: Call to a member function hasAccess() on null C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 6
ERROR - 2018-08-13 02:19:30 --> Severity: Notice --> Undefined property: stdClass::$access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 164
ERROR - 2018-08-13 02:19:30 --> Severity: Notice --> Undefined property: stdClass::$access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 164
ERROR - 2018-08-13 02:21:31 --> Severity: Notice --> Undefined property: stdClass::$access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 164
ERROR - 2018-08-13 02:21:31 --> Severity: Notice --> Undefined property: stdClass::$access C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 164
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 134
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 143
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 143
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 143
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 134
ERROR - 2018-08-13 02:21:46 --> Severity: Notice --> Undefined property: stdClass::$fa_icon C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 143
ERROR - 2018-08-13 02:30:50 --> 404 Page Not Found: MasterDataSubMenu/submenulist
ERROR - 2018-08-13 02:30:56 --> 404 Page Not Found: MasterDataSubMenu/submenulist
ERROR - 2018-08-13 02:30:57 --> 404 Page Not Found: MasterDataSubMenu/submenulist
ERROR - 2018-08-13 02:30:57 --> 404 Page Not Found: MasterDataSubMenu/submenulist
ERROR - 2018-08-13 02:31:54 --> 404 Page Not Found: MasterDataScreen/screenlist
ERROR - 2018-08-13 02:32:23 --> 404 Page Not Found: MasterDataSubMenu/submenulist
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:44:53 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 59
ERROR - 2018-08-13 02:49:02 --> Severity: Notice --> Undefined property: MasterDataRole::$rm C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataRole.php 70
ERROR - 2018-08-13 02:49:02 --> Severity: error --> Exception: Call to a member function role_type_checker() on null C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataRole.php 70
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:49:59 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 83
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:52:36 --> Severity: Notice --> Undefined index: RoleAccess C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataRole_.php 84
ERROR - 2018-08-13 02:53:55 --> 404 Page Not Found: Not_found/index
ERROR - 2018-08-13 02:54:06 --> 404 Page Not Found: Not_found/index
ERROR - 2018-08-13 02:54:23 --> 404 Page Not Found: Not_found/index
ERROR - 2018-08-13 02:54:37 --> 404 Page Not Found: Not_found/index
ERROR - 2018-08-13 02:56:02 --> 404 Page Not Found: Not_found/index
ERROR - 2018-08-13 03:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\admingetfit\application\views\masterdata\rolelist.php 106
ERROR - 2018-08-13 03:46:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Only one usage of each socket address (protocol/network address/port) is normally permitted.
 C:\xampp\htdocs\admingetfit\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-08-13 03:46:11 --> Unable to connect to the database
ERROR - 2018-08-13 03:46:19 --> 404 Page Not Found: MasterDataPosition/positionlist
ERROR - 2018-08-13 05:59:26 --> Query error: Unknown column 'C.sys_id' in 'on clause' - Invalid query: SELECT `A`.*, `RoleName`, `PositionName`
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`SysID` = `A`.`MasterDataRoleID`
INNER JOIN `masterdataposition` as `C` ON `C`.`sys_id` = `A`.`positionID`
ERROR - 2018-08-13 06:23:14 --> Query error: Column 'BranchDetailsID' cannot be null - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `PositionID`, `MasterDataRoleID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('Jojo', '', 'Boi', '', 'jojoboi', '$2y$10$uUaxVX7O.FTMMryWtNA.guzAnoF1yJOczBTFkRiQrluW92Grs4W5m', 'jojoboi@gmail.com', NULL, '', NULL, NULL, '2', NULL, '2018-08-13 06:23:14', 0, '-', '-', '-')
ERROR - 2018-08-13 06:24:01 --> Query error: Column 'AddedBy' cannot be null - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `PositionID`, `MasterDataRoleID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('Jojo', '', 'Boi', '', 'jojoboi', '$2y$10$KG5etiFXwuQdWC6F9Exh4e.jaDx5If9gYoJODqjTyf8c.GVpBVSbC', 'jojoboi@gmail.com', NULL, '', '1', '2', '2', NULL, '2018-08-13 06:24:01', 0, '-', '-', '-')
ERROR - 2018-08-13 07:26:00 --> Severity: error --> Exception: Call to undefined method MainGymInformation_::add_gymbranch() C:\xampp\htdocs\admingetfit\application\controllers\registerbranch\MainGymInformation.php 170
ERROR - 2018-08-13 07:27:42 --> Query error: Unknown column 'LoginStatus' in 'field list' - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BarangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('Makati Makati', 'Jojo Boi', 'jojoboi@gmail.com', '', '', '', '', '', '', '', '', '', '', '', 'Bell Air', 'Makati', 'Metro Manila', 'Central Luzon', 'Philippines', '123', '1', '2018-08-13', NULL, NULL)
ERROR - 2018-08-13 07:28:23 --> Query error: Column 'BranchStatus' cannot be null - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BarangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `BranchStatus`, `DeleteStatus`) VALUES ('Makati Makati', 'Jojo Boi', 'jojoboi@gmail.com', '', '', '', '', '', '', '', '', '', '', '', 'Bell Air', 'Makati', 'Metro Manila', 'Central Luzon', 'Philippines', '123', '1', '2018-08-13', NULL, NULL)
ERROR - 2018-08-13 07:35:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\registerbranch\MainGymInformation_.php 62
ERROR - 2018-08-13 07:35:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\registerbranch\MainGymInformation_.php 63
ERROR - 2018-08-13 08:53:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT *
FROM 
ERROR - 2018-08-13 08:53:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 2 - Invalid query: SELECT *
FROM 
