<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-22 01:02:46 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 01:34:26 --> 404 Page Not Found: MasterDataTrainingImage/index
ERROR - 2018-08-22 01:35:19 --> Query error: Table 'getfit1.masterdatatrainingimage' doesn't exist - Invalid query: SELECT `A`.*
FROM `masterdatatrainingimage` as `A`
ERROR - 2018-08-22 01:35:51 --> Query error: Table 'getfit1.masterdatatrainingimage' doesn't exist - Invalid query: SELECT `A`.*
FROM `masterdatatrainingimage` as `A`
ERROR - 2018-08-22 01:53:59 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 02:13:21 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 02:30:56 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 02:50:16 --> 404 Page Not Found: NaN8fdc752b4074463bb7ae6021b9b8da08jpgNaNMachine%201/index
ERROR - 2018-08-22 02:52:49 --> 404 Page Not Found: NaN8fdc752b4074463bb7ae6021b9b8da08jpgNaNMachine%201/index
ERROR - 2018-08-22 02:54:22 --> 404 Page Not Found: NaN8fdc752b4074463bb7ae6021b9b8da08jpgNaNMachine%201/index
ERROR - 2018-08-22 03:08:48 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 03:17:30 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 03:18:57 --> 404 Page Not Found: Uploads/images
ERROR - 2018-08-22 07:32:05 --> Query error: Unknown column 'VideoCategory' in 'field list' - Invalid query: INSERT INTO `masterdatatrainingvideo` (`VideoTitle`, `VideoDescription`, `VideoOrderIndex`, `VideoStatus`, `DeleteStatus`, `VideoCategory`, `VideoLink`, `AddedBy`, `AddedDate`) VALUES (NULL, 'GetFit247walkthrough', '1', 'yes', 'no', '1', 'https://youtu.be/KEnqJxpNC28', '1', '2018-08-22')
ERROR - 2018-08-22 07:33:42 --> Query error: Column 'VideoTitle' cannot be null - Invalid query: INSERT INTO `masterdatatrainingvideo` (`VideoTitle`, `VideoDescription`, `VideoOrderIndex`, `VideoStatus`, `DeleteStatus`, `VideoCategory`, `VideoLink`, `AddedBy`, `AddedDate`) VALUES (NULL, 'GetFit247walkthrough', '1', 'yes', 'no', '1', 'https://youtu.be/KEnqJxpNC28', '1', '2018-08-22')
ERROR - 2018-08-22 07:34:54 --> Query error: Column 'VideoTitle' cannot be null - Invalid query: INSERT INTO `masterdatatrainingvideo` (`VideoTitle`, `VideoDescription`, `VideoOrderIndex`, `VideoStatus`, `DeleteStatus`, `VideoCategory`, `VideoLink`, `AddedBy`, `AddedDate`) VALUES (NULL, 'GetFit247walkthrough', '1', 'yes', 'no', '1', 'https://youtu.be/KEnqJxpNC28', '1', '2018-08-22')
ERROR - 2018-08-22 07:35:27 --> Query error: Column 'VideoTitle' cannot be null - Invalid query: INSERT INTO `masterdatatrainingvideo` (`VideoTitle`, `VideoDescription`, `VideoOrderIndex`, `VideoStatus`, `DeleteStatus`, `VideoCategory`, `VideoLink`, `AddedBy`, `AddedDate`) VALUES (NULL, 'https://youtu.be/KEnqJxpNC28', '', 'yes', 'no', '1', 'https://youtu.be/KEnqJxpNC28', '1', '2018-08-22')
ERROR - 2018-08-22 07:35:53 --> Query error: Column 'VideoTitle' cannot be null - Invalid query: INSERT INTO `masterdatatrainingvideo` (`VideoTitle`, `VideoDescription`, `VideoOrderIndex`, `VideoStatus`, `DeleteStatus`, `VideoCategory`, `VideoLink`, `AddedBy`, `AddedDate`) VALUES (NULL, 'https://youtu.be/KEnqJxpNC28', '1', 'yes', 'no', '4', 'https://youtu.be/KEnqJxpNC28', '1', '2018-08-22')
