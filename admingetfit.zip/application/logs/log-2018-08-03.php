<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-03 00:02:15 --> Severity: Notice --> Undefined property: Register::$user_management C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:02:15 --> Severity: error --> Exception: Call to a member function add_user() on null C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:10:48 --> Severity: Notice --> Undefined property: Register::$user_management C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:10:48 --> Severity: error --> Exception: Call to a member function add_user() on null C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:12:50 --> Severity: Notice --> Undefined property: Register::$user_management C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:12:50 --> Severity: error --> Exception: Call to a member function add_user() on null C:\xampp\htdocs\admingetfit\application\controllers\Register.php 94
ERROR - 2018-08-03 00:17:51 --> Severity: error --> Exception: Class Register already exists and doesn't extend CI_Model C:\xampp\htdocs\admingetfit\system\core\Loader.php 353
ERROR - 2018-08-03 00:17:51 --> Severity: error --> Exception: Class Register already exists and doesn't extend CI_Model C:\xampp\htdocs\admingetfit\system\core\Loader.php 353
ERROR - 2018-08-03 00:18:18 --> Severity: Compile Error --> Cannot declare class Register, because the name is already in use C:\xampp\htdocs\admingetfit\application\models\Register_.php 65
ERROR - 2018-08-03 00:18:52 --> Query error: Unknown column 'BranchName' in 'field list' - Invalid query: INSERT INTO `gymmainlogin` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BrangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdateBy`, `UpodatedDate`, `BranchStatus`, `DeletedStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:20:26 --> Query error: Unknown column 'BranchName' in 'field list' - Invalid query: INSERT INTO `gymmainlogin` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BrangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdateBy`, `UpodatedDate`, `BranchStatus`, `DeletedStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:20:55 --> Query error: Unknown column 'BrangayName' in 'field list' - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BrangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdateBy`, `UpodatedDate`, `BranchStatus`, `DeletedStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:21:17 --> Query error: Unknown column 'UpdateBy' in 'field list' - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BarangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdateBy`, `UpodatedDate`, `BranchStatus`, `DeletedStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:21:43 --> Query error: Unknown column 'DeletedStatus' in 'field list' - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BarangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `BranchStatus`, `DeletedStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:21:59 --> Query error: Column 'AddedBy' cannot be null - Invalid query: INSERT INTO `branchdetails` (`BranchName`, `ContactPerson`, `EmailAddress`, `LandlineNumber`, `MobileNumber`, `HouseNumber`, `Lot`, `Block`, `Phase`, `FloorNumber`, `BuildingName`, `StreetName`, `PurokName`, `SubdivisionName`, `BarangayName`, `CityName`, `ProvinceName`, `RegionName`, `CountryName`, `ZipCode`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `BranchStatus`, `DeleteStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 00:29:52 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-03 00:29:52 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-03 00:29:52 --> Severity: Notice --> Undefined property: stdClass::$sys_id C:\xampp\htdocs\admingetfit\application\models\Register_.php 23
ERROR - 2018-08-03 00:29:52 --> Severity: Notice --> Undefined property: stdClass::$role_type C:\xampp\htdocs\admingetfit\application\models\Register_.php 24
ERROR - 2018-08-03 00:29:52 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\admingetfit\application\models\Register_.php 25
ERROR - 2018-08-03 00:29:52 --> Severity: Notice --> Undefined property: stdClass::$date_created C:\xampp\htdocs\admingetfit\application\models\Register_.php 26
ERROR - 2018-08-03 00:29:52 --> Severity: error --> Exception: Call to undefined method Register_::getmenulist_byid() C:\xampp\htdocs\admingetfit\application\models\Register_.php 27
ERROR - 2018-08-03 00:30:15 --> Severity: Notice --> Undefined property: stdClass::$sys_id C:\xampp\htdocs\admingetfit\application\models\Register_.php 23
ERROR - 2018-08-03 00:30:15 --> Severity: Notice --> Undefined property: stdClass::$role_type C:\xampp\htdocs\admingetfit\application\models\Register_.php 24
ERROR - 2018-08-03 00:30:15 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\admingetfit\application\models\Register_.php 25
ERROR - 2018-08-03 00:30:15 --> Severity: Notice --> Undefined property: stdClass::$date_created C:\xampp\htdocs\admingetfit\application\models\Register_.php 26
ERROR - 2018-08-03 00:30:15 --> Severity: error --> Exception: Call to undefined method Register_::getmenulist_byid() C:\xampp\htdocs\admingetfit\application\models\Register_.php 27
ERROR - 2018-08-03 00:30:34 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\admingetfit\application\models\Register_.php 30
ERROR - 2018-08-03 00:30:34 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\admingetfit\application\models\Register_.php 30
ERROR - 2018-08-03 00:30:34 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\admingetfit\application\models\Register_.php 30
ERROR - 2018-08-03 01:22:19 --> Query error: Unknown column 'FirstName' in 'field list' - Invalid query: INSERT INTO `branchdetails` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `confirmpassword`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '123', '123', 1, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 01:23:01 --> Query error: Unknown column 'confirmpassword' in 'field list' - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `confirmpassword`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', 'qwe', NULL, '123', '123', 1, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 01:23:48 --> Query error: Unknown column 'confirmpassword' in 'field list' - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `confirmpassword`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', '$2y$10$GI9tFB5dZ6pqBfU0LNXio.pYZKvLhcGDWgNCf7KV2TI.aKZT1MTzS', 'qwe', 'qwe', NULL, '123', '123', 1, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 01:24:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`getfitadmin`.`gymmainlogin`, CONSTRAINT `gymmainlogin_ibfk_1` FOREIGN KEY (`BranchDetailsID`) REFERENCES `branchdetails` (`SysID`)) - Invalid query: INSERT INTO `gymmainlogin` (`FirstName`, `MiddleName`, `LastName`, `Suffix`, `UserName`, `Password`, `EmailAddress`, `LandLineNumber`, `MobileNumber`, `BranchDetailsID`, `AddedBy`, `AddedDate`, `UpdatedBy`, `UpdatedDate`, `LoginStatus`, `DeleteStatus`) VALUES ('qwe', 'qwe', 'qwe', 'qwe', 'qwe', '$2y$10$QHsehHB49tcIl5K4ATB8aeQeRC6CWE0yM3TKHvpe6GdZBdk.rnXh.', 'qwe', NULL, '123', '123', 1, '2018-08-03', 0, '-', '-', '-')
ERROR - 2018-08-03 01:30:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'getfitadmin' C:\xampp\htdocs\admingetfit\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-08-03 01:30:05 --> Unable to connect to the database
ERROR - 2018-08-03 01:36:40 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:36:40 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:37:31 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:37:34 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:38:49 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:38:50 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 01:38:52 --> Unable to load the requested class: Authentication
ERROR - 2018-08-03 02:01:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-08-03 02:23:48 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\admingetfit\application\models\Login_model.php 52
ERROR - 2018-08-03 02:24:17 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\admingetfit\application\models\Login_model.php 52
ERROR - 2018-08-03 02:24:59 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\admingetfit\application\models\Login_model.php 52
ERROR - 2018-08-03 02:25:53 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\admingetfit\application\models\Login_model.php 52
ERROR - 2018-08-03 02:26:34 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\admingetfit\application\models\Login_model.php 53
ERROR - 2018-08-03 02:27:02 --> 404 Page Not Found: Home/index
ERROR - 2018-08-03 02:27:42 --> 404 Page Not Found: Home/index
ERROR - 2018-08-03 02:28:09 --> 404 Page Not Found: Home/index
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Undefined variable: c C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 218
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Trying to get property 'fa_icon' of non-object C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 218
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Undefined variable: c C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 218
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 218
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Undefined variable: c C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 227
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Trying to get property 'fa_icon' of non-object C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 227
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Undefined variable: c C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 227
ERROR - 2018-08-03 02:36:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 227
ERROR - 2018-08-03 03:14:12 --> 404 Page Not Found: MainUserInformation/index
ERROR - 2018-08-03 03:19:15 --> 404 Page Not Found: MainUserInformation/index
ERROR - 2018-08-03 03:20:39 --> 404 Page Not Found: MainUserInformation/index
ERROR - 2018-08-03 03:21:09 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:21:23 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:22:15 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:22:17 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:24:07 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:24:08 --> 404 Page Not Found: Mainuserinformation/index
ERROR - 2018-08-03 03:24:18 --> 404 Page Not Found: MainUserInformation/index
ERROR - 2018-08-03 03:25:38 --> 404 Page Not Found: registerbranch/MainBranchInformation/index
ERROR - 2018-08-03 03:26:37 --> 404 Page Not Found: registerbranch/MainBranchInformation/index
ERROR - 2018-08-03 03:42:23 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 03:42:23 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-03 03:42:23 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-03 03:42:23 --> 404 Page Not Found: User_management/ajax_load_user
ERROR - 2018-08-03 03:48:04 --> 404 Page Not Found: User_management/ajax_load_user
ERROR - 2018-08-03 03:48:04 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-03 03:48:04 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 03:48:04 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-03 03:49:19 --> 404 Page Not Found: User_management/ajax_load_user
ERROR - 2018-08-03 03:49:19 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-03 03:49:19 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 03:49:19 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-03 03:49:23 --> 404 Page Not Found: User_management/ajax_load_user
ERROR - 2018-08-03 03:49:23 --> 404 Page Not Found: Organization_master/ajax_load_division
ERROR - 2018-08-03 03:49:23 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 03:49:23 --> 404 Page Not Found: Organization_master/ajax_load_user_title
ERROR - 2018-08-03 06:32:34 --> Query error: Table 'getfit.user' doesn't exist - Invalid query: SELECT `username`
FROM `user`
WHERE `username` = 'lloyd'
ERROR - 2018-08-03 07:36:21 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:36:58 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:39:07 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:39:08 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:39:09 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:39:27 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:40:12 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:53:09 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:53:09 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 07:53:10 --> 404 Page Not Found: Masterdata/MasterDataRole
ERROR - 2018-08-03 08:11:13 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 08:12:06 --> 404 Page Not Found: Role_management/ajax_load_role
ERROR - 2018-08-03 08:57:31 --> 404 Page Not Found: Masterdatamenu/MasterDataMenu
