<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-06 23:58:09 --> 404 Page Not Found: Masterdatamenu/MasterDataMenu
