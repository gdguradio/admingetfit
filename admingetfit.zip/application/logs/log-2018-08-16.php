<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-16 01:09:32 --> 404 Page Not Found: masterdata/MasterDataMenu/insertMasterDataAdminImageGalleryFromAjax
ERROR - 2018-08-16 01:10:31 --> Query error: Unknown column 'ImageTitle' in 'field list' - Invalid query: INSERT INTO `masterdatamenu` (`ImageTitle`, `ImageDescription`, `HasChild`, `ImageLink`, `AddedBy`, `AddedDate`) VALUES ('First Image', 'First Image', '1', '51fb8c2b5977ace44132f270f521e1f2.png', '1', '2018-08-16')
ERROR - 2018-08-16 01:14:35 --> Query error: Unknown column 'HasChild' in 'field list' - Invalid query: INSERT INTO `masterdataadminimagegallery` (`ImageTitle`, `ImageDescription`, `HasChild`, `ImageLink`, `AddedBy`, `AddedDate`) VALUES ('First Image', 'First Image', '1', '31579301f45f578dd7e2979672b90570.png', '1', '2018-08-16')
ERROR - 2018-08-16 01:21:42 --> Severity: Notice --> Undefined variable: imagestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 74
ERROR - 2018-08-16 01:21:42 --> Severity: Notice --> Undefined variable: deletestatus C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 75
ERROR - 2018-08-16 01:21:42 --> Query error: Column 'ImageStatus' cannot be null - Invalid query: INSERT INTO `masterdataadminimagegallery` (`ImageTitle`, `ImageDescription`, `ImageOrderIndex`, `ImageStatus`, `DeleteStatus`, `ImageLink`, `AddedBy`, `AddedDate`) VALUES ('First Image', 'First Image', '1', NULL, NULL, 'f32a2ce62f8bec88e2277ce6935f53df.png', '1', '2018-08-16')
ERROR - 2018-08-16 02:08:05 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant data - assumed 'data' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 243
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant i - assumed 'i' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 243
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Illegal string offset 'i' C:\xampp\htdocs\admingetfit\application\views\index.php 243
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant ImageLink - assumed 'ImageLink' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 243
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant data - assumed 'data' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 252
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant i - assumed 'i' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 252
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Illegal string offset 'i' C:\xampp\htdocs\admingetfit\application\views\index.php 252
ERROR - 2018-08-16 02:30:30 --> Severity: Warning --> Use of undefined constant ImageLink - assumed 'ImageLink' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\admingetfit\application\views\index.php 252
ERROR - 2018-08-16 02:35:18 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-16 02:35:18 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-16 03:08:35 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 104
ERROR - 2018-08-16 03:08:35 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 108
ERROR - 2018-08-16 03:08:39 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 104
ERROR - 2018-08-16 03:08:39 --> Severity: Notice --> Undefined variable: photo C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataAdminImageGallery.php 108
ERROR - 2018-08-16 04:00:45 --> 404 Page Not Found: MasterDataBulletingBoard/bulletinboardlist
ERROR - 2018-08-16 05:31:10 --> Severity: error --> Exception: Call to undefined method MasterDataMenu_::loadBranch() C:\xampp\htdocs\admingetfit\application\controllers\masterdata\MasterDataBulletinBoard.php 30
ERROR - 2018-08-16 06:01:09 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$roleID C:\xampp\htdocs\admingetfit\application\models\Login_model.php 55
ERROR - 2018-08-16 06:05:23 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$roleID C:\xampp\htdocs\admingetfit\application\models\Login_model.php 55
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:17 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:41 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:42 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Couldn't fetch mysqli_result C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:06:43 --> Severity: Warning --> print_r(): Property access is not allowed yet C:\xampp\htdocs\admingetfit\application\views\templates\navigation.php 109
ERROR - 2018-08-16 06:07:05 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$roleID C:\xampp\htdocs\admingetfit\application\models\Login_model.php 55
ERROR - 2018-08-16 06:08:02 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$roleID C:\xampp\htdocs\admingetfit\application\models\Login_model.php 55
ERROR - 2018-08-16 06:14:42 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$BranchType C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 30
ERROR - 2018-08-16 06:26:55 --> 404 Page Not Found: User_management/ajax_delete_user
ERROR - 2018-08-16 06:56:30 --> Query error: Unknown column 'B.MasterDataRoleID' in 'on clause' - Invalid query: SELECT `B`.`SysID` AS `roleID`, `B`.`RoleName`
FROM `gymmainlogin` as `A`
INNER JOIN `masterdatarole` as `B` ON `B`.`MasterDataRoleID` = `B`.`SysID`
WHERE `A`.`BranchDetailsID` IS NULL
ERROR - 2018-08-16 07:12:26 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 26
ERROR - 2018-08-16 07:12:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:13:07 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 25
ERROR - 2018-08-16 07:13:07 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:16:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 25
ERROR - 2018-08-16 07:16:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:16:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 25
ERROR - 2018-08-16 07:16:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:16:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:16:47 --> Severity: error --> Exception: Call to undefined method MasterDataBulletinBoard_::loadScreen() C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:17:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:17:14 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:17:14 --> Severity: Notice --> Trying to get property 'MasterDataRoleID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:17:14 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:17:14 --> Severity: Notice --> Trying to get property 'MasterDataRoleID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:17:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:18:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:19:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:19:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:19:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:22:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:22:31 --> Severity: Notice --> Undefined index: SysID C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:22:31 --> Severity: Notice --> Undefined index: RoleName C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:22:31 --> Severity: Notice --> Undefined index: SysID C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:22:31 --> Severity: Notice --> Undefined index: RoleName C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:22:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:22:48 --> Severity: Notice --> Undefined index: SysID C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:22:48 --> Severity: Notice --> Undefined index: RoleName C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:22:48 --> Severity: Notice --> Undefined index: SysID C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:22:48 --> Severity: Notice --> Undefined index: RoleName C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Trying to get property 'SysID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Trying to get property 'SysID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:23:46 --> Severity: Notice --> Trying to get property 'RoleName' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:24:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:24:20 --> Severity: Notice --> Undefined index: SysID C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:24:20 --> Severity: Notice --> Undefined index: RoleName C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:24:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:24:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 12
ERROR - 2018-08-16 07:24:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:24:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:25:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:25:19 --> Severity: Notice --> Trying to get property 'SysID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:25:19 --> Severity: Notice --> Trying to get property 'SysID' of non-object C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 11
ERROR - 2018-08-16 07:25:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:26:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:28:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:28:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:28:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:29:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:29:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 8
ERROR - 2018-08-16 07:29:33 --> Severity: Notice --> Undefined variable: rolenames C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 14
ERROR - 2018-08-16 07:30:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:30:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:34:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:36:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:36:47 --> Severity: Notice --> Undefined variable: rolenames C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 13
ERROR - 2018-08-16 07:37:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:38:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:40:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 9
ERROR - 2018-08-16 07:49:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 18
ERROR - 2018-08-16 07:50:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 18
ERROR - 2018-08-16 07:51:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 18
ERROR - 2018-08-16 07:51:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 18
ERROR - 2018-08-16 07:51:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 18
ERROR - 2018-08-16 07:56:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-16 07:56:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-16 08:00:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-16 08:07:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-16 08:12:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 20
ERROR - 2018-08-16 08:21:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 19
ERROR - 2018-08-16 08:22:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\admingetfit\application\models\masterdata\MasterDataBulletinBoard_.php 19
