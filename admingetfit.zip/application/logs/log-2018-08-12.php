<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-08-12 23:44:41 --> 404 Page Not Found: Assets/img
ERROR - 2018-08-12 23:51:32 --> 404 Page Not Found: Register/ajaxLoadRole
ERROR - 2018-08-12 23:51:32 --> 404 Page Not Found: Register/ajaxLoadBranch
